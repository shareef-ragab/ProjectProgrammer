
package projectprogrammer;


public interface ShowInformation {
    public String showData();
}
